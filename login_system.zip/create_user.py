import sqlite3
from getpass import getpass
from werkzeug.security import generate_password_hash

DB = "users.db"

email = input("Gmail: ").strip().lower()
password = getpass("Password: ")

if not email or not password:
    raise SystemExit("Gmail and password are required.")

with sqlite3.connect(DB) as conn:
    conn.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL
        )
    """)
    conn.execute(
        "INSERT INTO users (email, password_hash) VALUES (?, ?)",
        (email, generate_password_hash(password))
    )

print("User created successfully.")
